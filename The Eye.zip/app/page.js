"use client";
import { useState } from "react";

export default function Home() {
  const [image, setImage] = useState(null);
  const [status, setStatus] = useState("idle");
  const [result, setResult] = useState(null);

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Show preview immediately
    setImage(URL.createObjectURL(file));
    setStatus("loading");
    setResult(null);

    try {
      // Convert file to base64
      const reader = new FileReader();
      reader.readAsDataURL(file);
      
      reader.onload = async () => {
        const base64 = reader.result.split(",")[1];

        // Call your new API
        const response = await fetch("/api/verify-image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ image: base64, mimeType: file.type }),
        });

        const data = await response.json();
        setResult(data);
        setStatus("success");
      };
    } catch (error) {
      console.error(error);
      setStatus("error");
    }
  };

  return (
    <div style={{ padding: "50px", textAlign: "center", fontFamily: "sans-serif" }}>
      <h1>🌊 Flood Watch AI</h1>
      
      {/* The Upload Button */}
      <input 
        type="file" 
        accept="image/*" 
        onChange={handleFileChange} 
        style={{ padding: "20px", fontSize: "16px" }}
      />

      {/* Loading Message */}
      {status === "loading" && <p>🤖 Analyzing image...</p>}

      {/* Preview Image */}
      {image && <img src={image} style={{ width: "300px", marginTop: "20px", borderRadius: "10px" }} />}

     {/* The Result Box - UPDATED TO SHOW ERROR DETAILS */}
      {result && (
        <div style={{ 
          marginTop: "20px", 
          padding: "20px", 
          border: "2px solid", 
          borderColor: result.verified ? "green" : "red",
          backgroundColor: result.verified ? "#e6fffa" : "#fff5f5"
        }}>
          <h2>{result.verified ? "✅ Verified" : "❌ Rejected"}</h2>
          <p><strong>Reason:</strong> {result.reason}</p>
          
          {/* Show Technical Details if there is an error */}
          {!result.verified && result.details && (
            <div style={{ marginTop: "10px", padding: "10px", background: "#ffebeb", fontSize: "12px", borderRadius: "5px" }}>
              <strong>Debug Error:</strong> {result.details}
            </div>
          )}
        </div>
      )}
    </div>
  );
}